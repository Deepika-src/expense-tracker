import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

function Navbar() {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate("/");
    };

    const getInitial = () => {
        if (!user?.name) return "U";
        return user.name.charAt(0).toUpperCase();
    };

    return (
        <nav className="navbar">
            <Link to="/" className="navbar-brand">
                Expense Tracker
            </Link>

            <div className="navbar-right">
                {user ? (
                    <>
                        <span className="welcome-text">
                            Hi, {user.name}
                        </span>

                        <button
                            className="profile-icon"
                            onClick={() => navigate("/profile")}
                            title="View Profile"
                        >
                            {getInitial()}
                        </button>

                        <button
                            className="logout-btn"
                            onClick={handleLogout}
                        >
                            Logout
                        </button>
                    </>
                ) : (
                    <Link to="/login" className="login-link">
                        Login
                    </Link>
                )}
            </div>
        </nav>
    );
}

export default Navbar;